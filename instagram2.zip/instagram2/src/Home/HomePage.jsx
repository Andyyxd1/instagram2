import React from 'react';

function HomePage() {
  return (
    <div>
      <h1>HomePage</h1>
    </div>
  );
}

export default HomePage;